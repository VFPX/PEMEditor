* 7.30.00

#Define cnVersion         7.30.00
#Define cdVersionDate     January 31, 2018
#Define	ccPEMEVERSION     [PEM Editor - 7.30.00 - January 31, 2018 - 20180131]
#Define	ccThorVERSIONFILE [ThorVersion.txt]