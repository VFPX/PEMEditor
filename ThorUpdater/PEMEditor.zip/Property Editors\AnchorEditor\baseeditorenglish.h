*==============================
* Localization strings
*==============================

* Captions.

#define ccLOC_CAP_OK					'OK'
#define ccLOC_CAP_CANCEL				'Cancel'
#define ccLOC_CAP_APPLY					'Apply'

* Messages.

#define ccLOC_BAD_CALL					'This property editor should only be used when one or more objects with <<iif(upper(left(This.cProperty, 1)) $ "AEIOU", "an ", "a ") + This.cProperty>> property have been selected in the Form or Class Designers.'
