#include AnchorEditorEnglish.H
#include BaseEditor.H
#include FoxPro.H

#define ccCR							chr(13)
	* Carriage return
