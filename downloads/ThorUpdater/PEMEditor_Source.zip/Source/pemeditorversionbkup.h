#Define cnVersion				7.051
#Define cdVersionDate			Oct. 21, 2011
#Define	ccPEMEVERSION      		[PEM Editor cnVersion with IDE Tools - cdVersionDate]
