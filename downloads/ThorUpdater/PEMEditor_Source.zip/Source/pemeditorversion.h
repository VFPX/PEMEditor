* 7.40.00

#Define cnVersion         7.40.00
#Define cdVersionDate     Juni 13, 2020
#Define	ccPEMEVERSION     [PEM Editor - 7.40.00 - June 13, 2020 - 20200613]
#Define	ccThorVERSIONFILE [ThorVersion.txt]

*!*	* 7.30.02

*!*	#Define cnVersion         7.30.02
*!*	#Define cdVersionDate     February 26, 2019
*!*	#Define	ccPEMEVERSION     [PEM Editor - 7.30.02 - February 26, 2019 - 20190226]
*!*	#Define	ccThorVERSIONFILE [ThorVersion.txt]