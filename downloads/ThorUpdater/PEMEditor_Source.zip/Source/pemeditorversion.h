* 7.41.00

#Define cnVersion         7.41.02
#Define cdVersionDate     May 29, 2022
#Define	ccPEMEVERSION     [PEM Editor - 7.41.02 - May 29, 2022 - 20220529]
#Define	ccThorVERSIONFILE [ThorVersion.txt]
