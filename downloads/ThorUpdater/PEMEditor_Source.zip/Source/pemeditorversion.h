* 7.41.00

#Define cnVersion         7.41.04
#Define cdVersionDate     June 11, 2022
#Define	ccPEMEVERSION     [PEM Editor - 7.41.03 - June 10, 2022 - 20220611]
#Define	ccThorVERSIONFILE [ThorVersion.txt]
