* 7.41.07

#Define cnVersion         7.41.07
#Define cdVersionDate     February 6, 2023
#Define	ccPEMEVERSION     [PEM Editor - 7.41.07 - February 6, 2023 - 20230206]
#Define	ccThorVERSIONFILE [ThorVersion.txt]
