* 7.40.01

#Define cnVersion         7.40.03
#Define cdVersionDate     March 30, 2022
#Define	ccPEMEVERSION     [PEM Editor - 7.40.03 - March 30, 2022 - 20220330]
#Define	ccThorVERSIONFILE [ThorVersion.txt]

*!*	* 7.30.02

*!*	#Define cnVersion         7.30.02
*!*	#Define cdVersionDate     February 26, 2019
*!*	#Define	ccPEMEVERSION     [PEM Editor - 7.30.02 - February 26, 2019 - 20190226]
*!*	#Define	ccThorVERSIONFILE [ThorVersion.txt]