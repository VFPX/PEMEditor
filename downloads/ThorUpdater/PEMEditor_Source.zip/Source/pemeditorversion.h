* 7.41.00

#Define cnVersion         7.41.00
#Define cdVersionDate     April 01, 2022
#Define	ccPEMEVERSION     [PEM Editor - 7.41.00 - April 01, 2022 - 20220401]
#Define	ccThorVERSIONFILE [ThorVersion.txt]
