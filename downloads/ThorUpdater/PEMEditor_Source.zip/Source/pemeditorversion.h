* 7.40.00

#Define cnVersion         7.40.00
#Define cdVersionDate     March 26, 2022
#Define	ccPEMEVERSION     [PEM Editor - 7.40.00 - March 26, 2022 - 20220326]
#Define	ccThorVERSIONFILE [ThorVersion.txt]

*!*	* 7.30.02

*!*	#Define cnVersion         7.30.02
*!*	#Define cdVersionDate     February 26, 2019
*!*	#Define	ccPEMEVERSION     [PEM Editor - 7.30.02 - February 26, 2019 - 20190226]
*!*	#Define	ccThorVERSIONFILE [ThorVersion.txt]