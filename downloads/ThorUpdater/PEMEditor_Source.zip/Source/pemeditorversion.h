* 7.30.02

#Define cnVersion         7.30.02
#Define cdVersionDate     February 26, 2019
#Define	ccPEMEVERSION     [PEM Editor - 7.30.02 - February 26, 2019 - 20190226]
#Define	ccThorVERSIONFILE [ThorVersion.txt]