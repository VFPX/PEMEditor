* 7.40.01

#Define cnVersion         7.40.01
#Define cdVersionDate     March 29, 2022
#Define	ccPEMEVERSION     [PEM Editor - 7.40.01 - March 29, 2022 - 20220329]
#Define	ccThorVERSIONFILE [ThorVersion.txt]

*!*	* 7.30.02

*!*	#Define cnVersion         7.30.02
*!*	#Define cdVersionDate     February 26, 2019
*!*	#Define	ccPEMEVERSION     [PEM Editor - 7.30.02 - February 26, 2019 - 20190226]
*!*	#Define	ccThorVERSIONFILE [ThorVersion.txt]