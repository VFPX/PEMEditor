* 7.30.00

#Define cnVersion         7.30.01
#Define cdVersionDate     February 7, 2018
#Define	ccPEMEVERSION     [PEM Editor - 7.30.01 - February 7, 2018 - 20180207]
#Define	ccThorVERSIONFILE [ThorVersion.txt]