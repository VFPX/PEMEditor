* 7.41.05

#Define cnVersion         7.41.05
#Define cdVersionDate     October 30, 2022
#Define	ccPEMEVERSION     [PEM Editor - 7.41.05 - October 30, 2022 - 20221030]
#Define	ccThorVERSIONFILE [ThorVersion.txt]
