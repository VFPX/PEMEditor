* 7.41.06

#Define cnVersion         7.41.06
#Define cdVersionDate     November 2, 2022
#Define	ccPEMEVERSION     [PEM Editor - 7.41.06 - November 2, 2022 - 20221102]
#Define	ccThorVERSIONFILE [ThorVersion.txt]
